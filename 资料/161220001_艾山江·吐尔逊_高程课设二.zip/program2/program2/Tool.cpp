#include"Tool.h"
#include "UI.h"
#include"Lawn.h"
//��̬������ʼ����
vector<Newspaper> Newspaper::all;
int Newspaper::num = 0;



//vector<Bucket> Bucket::all;



//
// 
//void Bucket::print()
//{
//	vector<Bucket>::iterator it;
//	for (it = all.begin(); it != all.end(); it++)
//	{
//		MoveTo(it->pos[2], it->pos[3]);
//		cout << it->shap;
//	}
//}
//
//void Bucket::move()
//{
//	Lawn L;
//	for (size_t kk = 0; kk < this->get_num(); kk++)
//	{
//		if (pos[1] < 11)
//		{
//			for (size_t i = 0; i < L.get_num(); i++)
//			{
//				//�ҵ����ӵ�ǰһ����ƺ
//				if (L.all[i].pos[0] == this->pos[0] && L.all[i].pos[1] == this->pos[1] - 1)
//				{
//					for (size_t j = 0; j < L.all[i].what_P_AT.size(); j++)
//					{
//						//�������ֲ��
//						if (L.all[i].what_P_AT[j] == 0 || L.all[i].what_P_AT[j] == 9)//�Ѵ���Ҳ����
//						{
//							L.all[i].what_Z_AT.push_back(1);
//							L.all[i].how_much_Z_AT.push_back(all[kk].data[4]);
//							this->del_one_object(kk);
//						}
//						else
//						{
//							all[kk].shoot_CD[2]++;
//							if (all[kk].shoot_CD[2] == all[kk].shoot_CD[1])
//							{
//								MoveTo(all[kk].pos[2], all[kk].pos[3]);
//								for (size_t k = 0; k < all[kk].shap.size(); k++)
//									cout << " ";
//								if (all[kk].pos[2] + all[kk].shap.size() == 11 * (all[kk].pos[1] - 1))
//								{
//									MoveTo(all[kk].pos[2] + all[kk].shap.size(), all[kk].pos[1]);
//									cout << get_back_ground();
//									all[kk].pos[1]--;
//								}
//								all[kk].pos[2] -= 1;
//								all[kk].shoot_CD[2] = 0;
//							}
//						}
//					}//����ֲ��
//				}
//			}//���в�ƺ
//		}
//	}//�����ӵ�
//}
//
//vector<Iron_gate> Iron_gate::all;
//
//void Iron_gate::print()
//{
//	vector<Iron_gate>::iterator it;
//	for (it = all.begin(); it != all.end(); it++)
//	{
//		MoveTo(it->pos[2], it->pos[3]);
//		cout << it->shap;
//	}
//}
//
//void Iron_gate::move()
//{
//	Lawn L;
//	for (size_t kk = 0; kk < this->get_num(); kk++)
//	{
//		if (pos[1] < 11)
//		{
//			for (size_t i = 0; i < L.get_num(); i++)
//			{
//				//�ҵ����ӵ�ǰһ����ƺ
//				if (L.all[i].pos[0] == this->pos[0] && L.all[i].pos[1] == this->pos[1] - 1)
//				{
//					for (size_t j = 0; j < L.all[i].what_P_AT.size(); j++)
//					{
//						//�������ֲ��
//						if (L.all[i].what_P_AT[j] == 0 || L.all[i].what_P_AT[j] == 9)//�Ѵ���Ҳ����
//						{
//							L.all[i].what_Z_AT.push_back(1);
//							L.all[i].how_much_Z_AT.push_back(all[kk].data[4]);
//							this->del_one_object(kk);
//						}
//						else
//						{
//							all[kk].shoot_CD[2]++;
//							if (all[kk].shoot_CD[2] == all[kk].shoot_CD[1])
//							{
//								MoveTo(all[kk].pos[2], all[kk].pos[3]);
//								for (size_t k = 0; k < all[kk].shap.size(); k++)
//									cout << " ";
//								if (all[kk].pos[2] + all[kk].shap.size() == 11 * (all[kk].pos[1] - 1))
//								{
//									MoveTo(all[kk].pos[2] + all[kk].shap.size(), all[kk].pos[1]);
//									cout << get_back_ground();
//									all[kk].pos[1]--;
//								}
//								all[kk].pos[2] -= 1;
//								all[kk].shoot_CD[2] = 0;
//							}
//						}
//					}//����ֲ��
//				}
//			}//���в�ƺ
//		}
//	}//�����ӵ�
//}
//
//vector<Rugby> Rugby::all;
//
//void Rugby::print()
//{
//	vector<Rugby>::iterator it;
//	for (it = all.begin(); it != all.end(); it++)
//	{
//		MoveTo(it->pos[2], it->pos[3]);
//		cout << it->shap;
//	}
//}
//
//void Rugby::move()
//{
//	Lawn L;
//	for (size_t kk = 0; kk < this->get_num(); kk++)
//	{
//		if (pos[1] < 11)
//		{
//			for (size_t i = 0; i < L.get_num(); i++)
//			{
//				//�ҵ����ӵ�ǰһ����ƺ
//				if (L.all[i].pos[0] == this->pos[0] && L.all[i].pos[1] == this->pos[1] - 1)
//				{
//					for (size_t j = 0; j < L.all[i].what_P_AT.size(); j++)
//					{
//						//�������ֲ��
//						if (L.all[i].what_P_AT[j] == 0 || L.all[i].what_P_AT[j] == 9)//�Ѵ���Ҳ����
//						{
//							L.all[i].what_Z_AT.push_back(1);
//							L.all[i].how_much_Z_AT.push_back(all[kk].data[4]);
//							this->del_one_object(kk);
//						}
//						else
//						{
//							all[kk].shoot_CD[2]++;
//							if (all[kk].shoot_CD[2] == all[kk].shoot_CD[1])
//							{
//								MoveTo(all[kk].pos[2], all[kk].pos[3]);
//								for (size_t k = 0; k < all[kk].shap.size(); k++)
//									cout << " ";
//								if (all[kk].pos[2] + all[kk].shap.size() == 11 * (all[kk].pos[1] - 1))
//								{
//									MoveTo(all[kk].pos[2] + all[kk].shap.size(), all[kk].pos[1]);
//									cout << get_back_ground();
//									all[kk].pos[1]--;
//								}
//								all[kk].pos[2] -= 1;
//								all[kk].shoot_CD[2] = 0;
//							}
//						}
//					}//����ֲ��
//				}
//			}//���в�ƺ
//		}
//	}//�����ӵ�
//}
//
//vector<Pole_Vaulting> Pole_Vaulting::all;
//
//void Pole_Vaulting::print()
//{
//	vector<Pole_Vaulting>::iterator it;
//	for (it = all.begin(); it != all.end(); it++)
//	{
//		MoveTo(it->pos[2], it->pos[3]);
//		cout << it->shap;
//	}
//}
//
//void Pole_Vaulting::move()
//{
//	Lawn L;
//	for (size_t kk = 0; kk < this->get_num(); kk++)
//	{
//		if (pos[1] < 11)
//		{
//			for (size_t i = 0; i < L.get_num(); i++)
//			{
//				//�ҵ����ӵ�ǰһ����ƺ
//				if (L.all[i].pos[0] == this->pos[0] && L.all[i].pos[1] == this->pos[1] - 1)
//				{
//					for (size_t j = 0; j < L.all[i].what_P_AT.size(); j++)
//					{
//						//�������ֲ��
//						if (L.all[i].what_P_AT[j] == 0 || L.all[i].what_P_AT[j] == 9)//�Ѵ���Ҳ����
//						{
//							L.all[i].what_Z_AT.push_back(1);
//							L.all[i].how_much_Z_AT.push_back(all[kk].data[4]);
//							this->del_one_object(kk);
//						}
//						else
//						{
//							all[kk].shoot_CD[2]++;
//							if (all[kk].shoot_CD[2] == all[kk].shoot_CD[1])
//							{
//								MoveTo(all[kk].pos[2], all[kk].pos[3]);
//								for (size_t k = 0; k < all[kk].shap.size(); k++)
//									cout << " ";
//								if (all[kk].pos[2] + all[kk].shap.size() == 11 * (all[kk].pos[1] - 1))
//								{
//									MoveTo(all[kk].pos[2] + all[kk].shap.size(), all[kk].pos[1]);
//									cout << get_back_ground();
//									all[kk].pos[1]--;
//								}
//								all[kk].pos[2] -= 1;
//								all[kk].shoot_CD[2] = 0;
//							}
//						}
//					}//����ֲ��
//				}
//			}//���в�ƺ
//		}
//	}//�����ӵ�
//}
//
//vector<Baseball> Baseball::all;
//
//void Baseball::print()
//{
//	vector<Baseball>::iterator it;
//	for (it = all.begin(); it != all.end(); it++)
//	{
//		MoveTo(it->pos[2], it->pos[3]);
//		cout << it->shap;
//	}
//}
//
//void Baseball::move()
//{
//	Lawn L;
//	for (size_t kk = 0; kk < this->get_num(); kk++)
//	{
//		if (pos[1] < 11)
//		{
//			for (size_t i = 0; i < L.get_num(); i++)
//			{
//				//�ҵ����ӵ�ǰһ����ƺ
//				if (L.all[i].pos[0] == this->pos[0] && L.all[i].pos[1] == this->pos[1] - 1)
//				{
//					for (size_t j = 0; j < L.all[i].what_P_AT.size(); j++)
//					{
//						//�������ֲ��
//						if (L.all[i].what_P_AT[j] == 0 || L.all[i].what_P_AT[j] == 9)//�Ѵ���Ҳ����
//						{
//							L.all[i].what_Z_AT.push_back(1);
//							L.all[i].how_much_Z_AT.push_back(all[kk].data[4]);
//							this->del_one_object(kk);
//						}
//						else
//						{
//							all[kk].shoot_CD[2]++;
//							if (all[kk].shoot_CD[2] == all[kk].shoot_CD[1])
//							{
//								MoveTo(all[kk].pos[2], all[kk].pos[3]);
//								for (size_t k = 0; k < all[kk].shap.size(); k++)
//									cout << " ";
//								if (all[kk].pos[2] + all[kk].shap.size() == 11 * (all[kk].pos[1] - 1))
//								{
//									MoveTo(all[kk].pos[2] + all[kk].shap.size(), all[kk].pos[1]);
//									cout << get_back_ground();
//									all[kk].pos[1]--;
//								}
//								all[kk].pos[2] -= 1;
//								all[kk].shoot_CD[2] = 0;
//							}
//						}
//					}//����ֲ��
//				}
//			}//���в�ƺ
//		}
//	}//�����ӵ�
//}
//
//vector<Chemist> Chemist::all;
//
//
//void Chemist::print()
//{
//	vector<Chemist>::iterator it;
//	for (it = all.begin(); it != all.end(); it++)
//	{
//		MoveTo(it->pos[2], it->pos[3]);
//		cout << it->shap;
//	}
//}
//
//void Chemist::move()
//{
//	Lawn L;
//	for (size_t kk = 0; kk < this->get_num(); kk++)
//	{
//		if (pos[1] < 11)
//		{
//			for (size_t i = 0; i < L.get_num(); i++)
//			{
//				//�ҵ����ӵ�ǰһ����ƺ
//				if (L.all[i].pos[0] == this->pos[0] && L.all[i].pos[1] == this->pos[1] - 1)
//				{
//					for (size_t j = 0; j < L.all[i].what_P_AT.size(); j++)
//					{
//						//�������ֲ��
//						if (L.all[i].what_P_AT[j] == 0 || L.all[i].what_P_AT[j] == 9)//�Ѵ���Ҳ����
//						{
//							L.all[i].what_Z_AT.push_back(1);
//							L.all[i].how_much_Z_AT.push_back(all[kk].data[4]);
//							this->del_one_object(kk);
//						}
//						else
//						{
//							all[kk].shoot_CD[2]++;
//							if (all[kk].shoot_CD[2] == all[kk].shoot_CD[1])
//							{
//								MoveTo(all[kk].pos[2], all[kk].pos[3]);
//								for (size_t k = 0; k < all[kk].shap.size(); k++)
//									cout << " ";
//								if (all[kk].pos[2] + all[kk].shap.size() == 11 * (all[kk].pos[1] - 1))
//								{
//									MoveTo(all[kk].pos[2] + all[kk].shap.size(), all[kk].pos[1]);
//									cout << get_back_ground();
//									all[kk].pos[1]--;
//								}
//								all[kk].pos[2] -= 1;
//								all[kk].shoot_CD[2] = 0;
//							}
//						}
//					}//����ֲ��
//				}
//			}//���в�ƺ
//		}
//	}//�����ӵ�
//}

void Newspaper::print()
{
	vector<Newspaper>::iterator it;
	for (it = all.begin(); it != all.end(); it++)
	{
		MoveTo(it->pos[2], it->pos[3]);
		cout << it->shap;
	}
}

//���й������ʵ����


void Newspaper::move()
{
	//Lawn L;
	//for (size_t kk = 0; kk < this->get_num(); kk++)
	//{
	//	if (all[kk].is_can_move == 1)
	//	{
	//		if (all[kk].pos[1]>1)
	//		{






	//		}
	//	}

	//	if (pos[1] >1)
	//	{
	//		for (size_t i = 0; i < L.get_num(); i++)
	//		{
	//			//�ҵ����ӵ���ǰ��ƺ
	//			if (L.all[i].one_block[0] == all[kk].pos[0] && L.all[i].one_block[1] == all[kk].pos[1])
	//			{
	//				for (size_t j = 0; j < L.all[i].how_many_P.size(); j++)
	//				{
	//					//�������ֲ��
	//					if (L.all[i].how_many_P[j].type == 0 || L.all[i].how_many_P[j].type == 9)//�Ѵ���Ҳ����
	//					{
	//						L.all[i].zombie_attack(1, all[kk].ID, all[kk].pos, all[kk].data);
	//						for (size_t k = 0; k < all[kk].shap.size(); k++)
	//							cout << " ";
	//						this->del_one_object(kk);
	//					}
	//					else
	//					{
	//						all[kk].shoot_CD[2]++;
	//						if (all[kk].shoot_CD[2] == all[kk].shoot_CD[1])
	//						{
	//							MoveTo(all[kk].pos[2], all[kk].pos[3]);
	//							for (size_t k = 0; k < all[kk].shap.size(); k++)
	//								cout << " ";
	//							if (all[kk].pos[2] + all[kk].shap.size() == 11 * (all[kk].pos[1] - 1))
	//							{
	//								MoveTo(all[kk].pos[2] + all[kk].shap.size(), all[kk].pos[1]);
	//								cout << get_back_ground();
	//								all[kk].pos[1]--;
	//							}
	//							all[kk].pos[2] -= 1;
	//							all[kk].shoot_CD[2] = 0;
	//						}
	//					}
	//				}//����ֲ��
	//			}
	//		}//���в�ƺ
	//	}
	//}//�����ӵ�
}
