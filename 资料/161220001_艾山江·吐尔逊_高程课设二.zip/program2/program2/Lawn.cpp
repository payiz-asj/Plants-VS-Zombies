#include"Lawn.h"

vector<Lawn> Lawn::all;
