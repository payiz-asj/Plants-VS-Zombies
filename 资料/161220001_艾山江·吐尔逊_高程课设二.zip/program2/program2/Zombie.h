#pragma once 
#ifndef  ASJ_ZOMBI
#define  ASJ_ZOMBI

#include <Windows.h>
#include <string>
#include <tchar.h>
#include <time.h>
#include<vector>
#include <iostream>
#include <conio.h>
#include <sstream>
#include "Tool.h"
#include "Lawn.h"
#include "UI.h"
using namespace std;

class Zombies
{
public:
	Zombies(){}
	virtual ~Zombies(){}
	virtual void set_tool_type(const int &i) = 0;
	virtual void set_pos(const vector<int> & where) = 0;
	//virtual void set_solo_cd(const vector<int> & a) = 0;
	virtual void set_move_cd(const vector<int> & a) = 0;
	virtual void set_data(const vector<double> &a) = 0;
	virtual void create(const vector<int> & where) = 0;
	//virtual void del_one_object(const size_t &i) = 0;
	virtual void del_one_object(const string &id) = 0;
	virtual void push() = 0;
	virtual void Cannot_attack() = 0;
	virtual void Cannot_move() = 0;
	//��ȡ
	virtual int get_bullet_type() = 0;
	virtual Tool* get_tools() = 0;
	virtual vector<int> get_pos() = 0;
	virtual vector<double> get_data() = 0;
	virtual size_t get_num() = 0;
	virtual Zombies *get_one_object(const size_t &i) = 0;
	virtual string get_ID() = 0;

	//����
	virtual void print() = 0;
	virtual void attack() = 0;
	virtual void bite() = 0;
	virtual void solo() = 0;
	virtual void defance() = 0;
	virtual void move() = 0;
	virtual void move_up ()= 0;
	virtual void move_down() = 0;


protected:
	string name;
	string ID;
	vector<int> pos;    //0 row    1  col   2  x   3  y 
	vector<double>data;	//0 MAX_XL  1  MAX_AT   2  MAX_DF  3 XL   4 AT  5  DF
	vector<int>bite_CD;	// 0  bite_CD   1  bite_CD_begin
	vector<int>solo_CD;	// 0  solo_CD   1  solo_CD_begin
	vector<int>move_CD;	// 0  move_CD   1  move_CD_begin
	bool    is_alive;
	bool    is_can_attack;
	bool    is_can_solo;
	bool    is_can_move;
	

};

class Ordinary :public Zombies
{
	static vector<Ordinary> all;
	Tool *my_Tools;
	int what_tool;
	static int num;
public:
	Ordinary()
	{
		name = "��ʬ";
		ID = "��ͨ��ʬ";
		data = { 300, 100, 300, 300, 100, 300 };
		bite_CD = { 10, 0 };
		solo_CD = { 10, 0 };
		move_CD = { 10, 0 };
		is_alive = 1;
		is_can_attack = 0;
		is_can_solo = 0;	
		is_can_move = 1;
		what_tool = 0;
		my_Tools = NULL;
		num++;
	}
	~Ordinary(){}


	void set_tool_type(const int &i)
	{
		what_tool = i;
	}
	Tool *get_tools()
	{
		return my_Tools;
	}
	void set_pos(const vector<int> & where)
	{
		pos = where;
	}
	void set_solo_cd(const vector<int> & a)
	{
		solo_CD = a;
	}
	void set_move_cd(const vector<int> & a)
	{
		move_CD = a;
	}

	void set_data(const vector<double> &a)
	{
		data = a;
	}
	void create(const vector<int> & where);
	/*void del_one_object(const size_t &i)
	{
	size_t k = 0;
	vector<Ordinary>::iterator it;
	for (it = all.begin(); it != all.end(); it++, k++)
	{
	if (k == i)
	{
	it = all.erase(it);
	break;
	}
	}
	}*/
	void del_one_object(const string & id)
	{
		vector<Ordinary>::iterator it;
		for (it = all.begin(); it != all.end(); it++)
		{
			if (it->ID == id)
			{
				it = all.erase(it);
				break;
			}
		}
	}
	void push()
	{
		all.push_back(*this);
	}
	void Cannot_attack()
	{
		is_can_attack = 0;
	}
	void Cannot_move()
	{
		is_can_move = 0;
	}

	//��ȡ����
	int get_bullet_type()
	{
		return what_tool;
	}
	Tool *get_bullets()
	{
		return my_Tools;
	}
	vector<int> get_pos()
	{
		return pos;
	}
	vector<double>get_data()
	{
		return data;
	}
	size_t get_num()
	{
		return all.size();
	}
	Zombies *get_one_object(const size_t &i)
	{
		return &all[i];
	}
	string get_ID()
	{
		return ID;
	}

	//����
	void print();
	void attack();

	void bite();

	void solo()
	{

	}
	void defance();

	void move_up();
	void move_down();
	void move();

	void moving()
	{




	}
	void knock_wall()
	{

	}


};







////Զ�̽�ʬ
//class Z_01 :public Zombies
//{
//	static vector<Z_01> all;
//	Tool *my_Tools;
//	int what_tool;
//public:
//	Z_01()
//	{
//		name = "Զ�̽�ʬ";
//		type = "Զ�̽�ʬ";
//		MAX_XL = 100;
//		XL = 100;
//		AT = 30;
//		SP = 20;
//		SP_begin = 0;
//		is_alive = 1;
//		//��ʼ��һ������
//		what_tool = 0;
//		my_Tools = new Baseball;
//		
//	}
//	~Z_01(){}
//	void set_pos(const int &a, const int &b);
//	void select_tool(int i)
//	{
//		what_tool = i;
//	}
//	void create(const int &a, const int &b);
//	void print();
//	void attak()
//	{
//		bite();
//	}
//	void move();
//	void push()
//	{
//		all.push_back(*this);
//	}
//	size_t get_num()
//	{
//		return all.size();
//	}
//	void bite()
//	{
//
//	}
//	Zombies* get_one_object(size_t i)
//	{
//		return &all[i];
//	}
//	void hit_one_object(size_t i, double at)
//	{
//		all[i].XL -= at;
//	}
//	int get_row()
//	{
//		return row;
//	}
//	int get_col()
//	{
//		return col;
//	}
//	string get_type()
//	{
//		return type;
//	}
//	Tool * get_tool()
//	{
//		return my_Tools;
//	}
//	int get_tool_type()
//	{
//		return what_tool;
//	}
//
//};
//
////���̽�ʬ
//class Z_02 :public Zombies
//{
//	static vector<Z_02> all;
//	Tool *my_Tools;
//	int what_tool;
//public:
//	Z_02()
//	{
//		name = "���̽�ʬ";
//		type = "���̽�ʬ";
//		MAX_XL = 100;
//		XL = 100;
//		AT = 30;
//		SP = 20;
//		SP_begin = 0;
//		is_alive = 1;
//		//��ʼ��һ������
//		what_tool = 0;
//		my_Tools = new Pole_Vaulting;
//		
//	}
//	~Z_02(){}
//	void set_pos(const int &a, const int &b);
//	void select_tool(int i)
//	{
//		what_tool = i;
//	}
//	void create(const int &a, const int &b);
//	void print();
//	void attak()
//	{
//		bite();
//	}
//	void move();
//	void push()
//	{
//		all.push_back(*this);
//	}
//	size_t get_num()
//	{
//		return all.size();
//	}
//	void bite()
//	{
//
//	}
//	Zombies* get_one_object(size_t i)
//	{
//		return &all[i];
//	}
//	void hit_one_object(size_t i, double at)
//	{
//		all[i].XL -= at;
//	}
//	int get_row()
//	{
//		return row;
//	}
//	int get_col()
//	{
//		return col;
//	}
//	string get_type()
//	{
//		return type;
//	}
//	Tool * get_tool()
//	{
//		return my_Tools;
//	}
//	int get_tool_type()
//	{
//		return what_tool;
//	}
//};
//
//
//
//
//
////Kunkun
//class Kunkun :public Zombies
//{
//	static vector<Kunkun> all;
//	Tool *my_Tools;
//	int what_tool;
//	int is_about_to_die;
//public:
//	Kunkun()
//	{
//		name = "������ʬ";
//		type = "������ʬ";
//		MAX_XL = 100;
//		XL = 100;
//		AT = 30;
//		SP = 50;
//		SP_begin = 0;
//		is_alive = 1;
//		is_about_to_die = 0;
//		//��ʼ��һ������
//		what_tool = 0;
//		my_Tools = NULL;
//		
//	}
//	~Kunkun(){}
//	void set_pos(const int &a, const int &b);
//	void select_tool(int i)
//	{
//		what_tool = i;
//	}
//	void create(const int &a, const int &b);
//	void print();
//	void attak()
//	{
//		bite();
//	}
//	void move();
//	void push()
//	{
//		all.push_back(*this);
//	}
//	size_t get_num()
//	{
//		return all.size();
//	}
//	void bite()
//	{
//
//	}
//	Zombies* get_one_object(size_t i)
//	{
//		return &all[i];
//	}
//	void hit_one_object(size_t i, double at)
//	{
//		all[i].XL -= at;
//	}
//	int get_row()
//	{
//		return row;
//	}
//	int get_col()
//	{
//		return col;
//	}
//	string get_type()
//	{
//		return type;
//	}
//	Tool * get_tool()
//	{
//		return my_Tools;
//	}
//	int get_tool_type()
//	{
//		return what_tool;
//	}
//};
//


#endif 





