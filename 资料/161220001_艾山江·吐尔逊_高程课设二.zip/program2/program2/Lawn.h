
#ifndef  ASJ_LAWN
#define  ASJ_LAWN

#include "UI.h"

#include <Windows.h>
#include <string>
#include <tchar.h>
#include <time.h>
#include<vector>
#include <iostream>
#include <conio.h>
using namespace std;

struct one_P
{
	int type;
	string ID;
	vector<int>pos;
	vector<double>data;
};
struct one_Z
{
	int type;
	string ID;
	vector<int>pos;
	vector<double>data;

};

class Lawn
{
public:
	static vector<Lawn> all;
	vector<int>one_block;     //0  row    1    col

	vector<one_P>how_many_P;    
	vector<one_Z>how_many_Z;

	//��ɫ

	Lawn()
	{

	}
	~Lawn()
	{

	}
	//��ʼ�����в�ƺ
	void init_lawn()
	{
		int max_row = get_chicun()[0];
		int max_col = get_chicun()[1];
		for (int i = 1; i <= max_row; i++)
		{
			for (int j = 1; j <= max_col; j++)
			{
				Lawn *L = new Lawn;
				L->one_block = create_pos(i, j);
				L->push();
			}
		}
	}
	void push()
	{
		all.push_back(*this);
	}
	void plant_attack(const int &t,const string &id,const vector<int>&p,const vector<double> d)
	{
		one_P it;
		it.type = t;
		it.ID = id;
		it.pos = p;
		it.data = d;
		how_many_P.push_back(it);
	}
	void zombie_attack(const int &t, const string &id, const vector<int>&p, const vector<double> d)
	{
		one_Z it;
		it.type = t;
		it.ID = id;
		it.pos = p;
		it.data = d;
		how_many_Z.push_back(it);

	}
	void del_zombie_attack(const string &id)
	{
		vector<one_Z>::iterator it;
		vector<int>w = this->one_block;
		int sii = this->how_many_Z.size();
		for (it = this->how_many_Z.begin(); it != this->how_many_Z.end(); it++)
		{
			if (it->ID == id)
			{
				it = this->how_many_Z.erase(it);
				sii = this->how_many_Z.size();
				break;
			}
		}
		sii = this->how_many_Z.size();
	}
	void del_plant_attack(const string &id)
	{
		vector<one_P>::iterator it;
		for (it = this->how_many_P.begin(); it != this->how_many_P.end(); it++)
		{
			if (it->ID == id)
			{
				it = this->how_many_P.erase(it);
				break;
			}
		}
	}
	Lawn get_one_object(const size_t &i)
	{
		return all[i];
	}
	void del_one_object(const size_t &i)
	{
		size_t k = 0;
		vector<Lawn>::iterator it;
		for (it = all.begin(); it != all.end(); it++, k++)
		{
			if (k == i)
			{
				it = all.erase(it);
				break;
			}
		}
	}
	void del_one_plant(const size_t &i)
	{
		size_t kk = 0;
		vector<one_P>::iterator it2;
		for (it2 = this->how_many_P.begin(); it2 != this->how_many_P.end(); it2++, kk++)
		{
			if (kk == i)
			{
				it2 = this->how_many_P.erase(it2);
				break;
			}
		}
	}
	void del_one_zombie(const size_t &i)
	{
		size_t k = 0;
		vector<one_Z>::iterator it;
		for (it = this->how_many_Z.begin(); it != this->how_many_Z.end(); it++, k++)
		{
			if (k == i)
			{
				it = this->how_many_Z.erase(it);
				break;
			}
		}
	}


	size_t get_num()
	{
		return all.size();
	}
	vector<int> get_pos()
	{
		return one_block;
	}



};




#endif 