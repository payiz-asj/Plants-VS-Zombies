#include"Zombie.h"
#include "UI.h"
#include"Lawn.h"
//��̬������ʼ����
vector<Ordinary> Ordinary::all;
int Ordinary::num = 0;

void Ordinary::create(const vector<int> & where)
{
	vector<int> w;
	w = create_pos(where[0], where[1] - 1);
	//���ӹ���
	switch (what_tool)
	{
	case 0:
	{
		my_Tools = NULL;
		break;
	}
	case 1:
	{
		my_Tools = new Newspaper;
		my_Tools->create(w, this->ID);
		break;
	}
	/*case 2:
	{
	my_Tools = new Bucket;
	my_Tools->create(w, this->ID);
	break;
	}
	case 3:
	{
	my_Tools = new Iron_gate;
	my_Tools->create(w, this->ID);
	break;
	}
	case 4:
	{
	my_Tools = new Rugby;
	my_Tools->create(w, this->ID);
	break;
	}*/

	default:
		my_Tools = NULL;
		break;
	}

	//���ɴ˽�ʬ
	this->set_pos(where);
	this->move_CD[0] += my_Tools->get_cd()[1];
	this->name = my_Tools->get_name() + name;
	stringstream Oss;
	Oss << num;
	int num2 = my_Tools->what_num();
	stringstream Oss2;
	Oss2 << num2;
	this->ID = this->name + Oss.str()+Oss2.str();
	this->push();
}

void Ordinary::print()
{
	Lawn L;
	for (size_t kk = 0; kk < this->get_num(); kk++)
	{
		if (all[kk].is_alive == 1)
		{
			/*int count = 0;
			for (size_t i = 0; i < L.get_num(); i++)
			{
			for (size_t j = 0; j < L.all[i].how_many_Z.size(); j++)
			{
			if (L.all[i].how_many_Z[j].type == 0)
			{
			count++;
			}
			}
			}
			if (count)
			*/
			MoveTo(all[kk].pos[2], all[kk].pos[3]);
			cout << all[kk].name;
		}
		else
		{
			MoveTo(all[kk].pos[2], all[kk].pos[3]);
			for (size_t k = 0; k < all[kk].name.size(); k++)
				cout << " ";
			this->del_one_object(all[kk].ID);
		}
	}
}

void Ordinary::attack()
{

	Lawn L;
	for (size_t kk = 0; kk < this->get_num(); kk++)
	{
		all[kk].is_can_attack = 0;
		all[kk].is_can_solo = 0;
		all[kk].is_can_move = 1;
		if (all[kk].pos[1] < 11)
		{
			if (all[kk].is_alive == 1)
			{
				for (size_t i = 0; i < L.get_num(); i++)
				{
					//�ҵ��ý�ʬǰһ����ƺ
					if (L.all[i].one_block[0] == all[kk].pos[0] && L.all[i].one_block[1] == all[kk].pos[1] - 1)
					{
						for (size_t j = 0; j < L.all[i].how_many_P.size(); j++)
						{
							//�������ֲ��
							if (L.all[i].how_many_P[j].type == 0)
							{
								all[kk].is_can_attack = 1;
								all[kk].is_can_move = 0;
							}
						}
					}
				}
				//�ж�solo����
				if (all[kk].is_can_attack == 1)
				{
					all[kk].bite();
				}
			}
		}
	}
}

void Ordinary::bite()
{
	for (size_t kk = 0; kk < this->get_num(); kk++)
	{
		all[kk].bite_CD[1]++;
		if (all[kk].bite_CD[1] == all[kk].bite_CD[0])
		{
			Lawn L;
			for (size_t i = 0; i < L.get_num(); i++)
			{
				if (L.all[i].one_block[0] == all[kk].pos[0] && L.all[i].one_block[1] == all[kk].pos[1] - 1)
				{
					L.all[i].zombie_attack(0, all[kk].ID, all[kk].pos, all[kk].data);
				}
			}
			all[kk].bite_CD[1] = 0;
		}
	}
}

void Ordinary::defance()
{
	Lawn L;
	for (size_t kk = 0; kk < this->get_num(); kk++)
	{
		if (all[kk].pos[1] < 11)
		{
			for (size_t i = 0; i < L.get_num(); i++)
			{
				//�ҵ��ý�ʬ���ڲ�ƺ
				if (L.all[i].one_block[0] == all[kk].pos[0] && L.all[i].one_block[1] == all[kk].pos[1])
				{
					for (size_t j = 0; j < L.all[i].how_many_P.size(); j++)
					{
						//����ǵ����˺�������ʬѭ�����
						if (L.all[i].how_many_P[j].type == 1)
						{
							vector<int> w = create_pos(all[kk].pos[0], all[kk].pos[1]);

							vector<int> ewww = all[kk].pos;
							if (all[kk].pos[3] == w[3])//��һ�н�ʬ������ǰ��Ľ�ʬ
							{
								if (all[kk].data[5] > L.all[i].how_many_P[j].data[4])
								{
									all[kk].data[5] -= L.all[i].how_many_P[j].data[4];
								}
								else
								{
									all[kk].data[5] = 0;
									all[kk].data[3] = all[kk].data[3] - L.all[i].how_many_P[j].data[4] + all[kk].data[5];
								}
								//ɾ�����˺�
								L.all[i].del_plant_attack(L.all[i].how_many_P[j].ID);
							}
						}
						else
						{
							vector<int> w = create_pos(this->pos[0], this->pos[1]);
							if (all[kk].pos[3] == w[3])//��һ�н�ʬ������ǰ��Ľ�ʬ
							{
								if (all[kk].data[5] > L.all[i].how_many_P[j].data[4])
								{
									all[kk].data[5] -= L.all[i].how_many_P[j].data[4];
								}
								else
								{
									all[kk].data[5] = 0;
									all[kk].data[3] = all[kk].data[3] - L.all[i].how_many_P[j].data[4] + all[kk].data[5];
								}
								//ɾ�����˺�
								L.all[i].del_plant_attack(L.all[i].how_many_P[j].ID);
							}
						}
						if (all[kk].data[3] <= 0)
						{
							all[kk].is_alive = 0;
							L.all[i].del_zombie_attack(all[kk].ID);
						}
							
					}//�ò�ƺ�����˺��������

				}
			}
		}
	}
}

void Ordinary::move_up()
{
	MoveTo(pos[0], pos[1]);
	for (size_t k = 0; k < name.size(); k++)
		cout << " ";
	if (pos[2] + name.size() == 11 * (pos[1] - 1))
	{
		MoveTo(pos[2] + name.size(), pos[1]);
		cout << get_back_ground();
		pos[1]--;
	}
	pos[0]--;
}

void Ordinary::move_down()
{
	MoveTo(pos[0], pos[1]);
	for (size_t k = 0; k < name.size(); k++)
		cout << " ";
	if (pos[2] + name.size() == 11 * (pos[1] - 1))
	{
		MoveTo(pos[2] + name.size(), pos[1]);
		cout << get_back_ground();
		pos[1]--;
	}
	pos[0]++;
}

void Ordinary::move()
{
	Lawn L;
	for (size_t kk = 0; kk < this->get_num(); kk++)
	{
		if (all[kk].is_can_move == 1)
		{
			if (all[kk].pos[1]>0)
			{
				if (all[kk].pos[1] <= get_screen_data()[1])
				{
					int meet_plant = 0;
					for (size_t i = 0; i < L.get_num(); i++)
					{
						bool is_time_to_break = 0;
						//�ҵ��ý�ʬ���ڲ�ƺ
						if (L.all[i].one_block[0] == all[kk].pos[0] && L.all[i].one_block[1] == all[kk].pos[1])
						{	
							
							is_time_to_break = 1;
							for (size_t j = 0; j < L.all[i].how_many_P.size(); j++)
							{
								//������ִ���
								if (L.all[i].how_many_P[j].type == 9)
								{
									meet_plant = 1;
									if (all[kk].pos[0]>3)
										move_up();
									else
										move_down();
									break;
								}
								else
								{		
									//L.all[i].zombie_attack(0, all[kk].ID, all[kk].pos, all[kk].data);
									break;
								}
							}
						}
						if (is_time_to_break == 1)
							break;
					}
					if (meet_plant == 0)
					{
						all[kk].move_CD[1]++;
						if (all[kk].move_CD[1] == all[kk].move_CD[0])
						{
							MoveTo(all[kk].pos[2], all[kk].pos[3]);
							for (size_t k = 0; k < all[kk].name.size(); k++)
								cout << " ";
							if (all[kk].pos[2] == create_pos(all[kk].pos[0], all[kk].pos[1])[2] - 1)
							{
								all[kk].pos[1]--;
							}
							if (all[kk].pos[2] + all[kk].name.size() == create_pos(all[kk].pos[0], all[kk].pos[1])[2] + get_screen_data()[2])
							{
								MoveTo(all[kk].pos[2] + all[kk].name.size(), all[kk].pos[3]);
								cout << get_back_ground();
							}
							all[kk].pos[2] -= 1;
							for (size_t i = 0; i < L.get_num(); i++)
							{
								if (L.all[i].one_block[0] == all[kk].pos[0] && L.all[i].one_block[1] == all[kk].pos[1])
								{
									L.all[i].zombie_attack(0, all[kk].ID, all[kk].pos, all[kk].data);
								}
							}
							all[kk].move_CD[1] = 0;
							
						}
					}
				}
				else
				{
					all[kk].move_CD[1]++;
					if (all[kk].move_CD[1] == all[kk].move_CD[0])
					{
						MoveTo(all[kk].pos[2], all[kk].pos[3]);
						for (size_t k = 0; k < all[kk].name.size(); k++)
							cout << " ";
						if (all[kk].pos[2] == create_pos(all[kk].pos[0], all[kk].pos[1])[2]-1)
						{
							all[kk].pos[1]--;

						}
						all[kk].pos[2] -= 1;
						all[kk].move_CD[1] = 0;
					}
				}
			}
			else
			{

				all[kk].is_alive = 0;
				/*MoveTo(all[kk].pos[2], all[kk].pos[3]);
				for (size_t k = 0; k < all[kk].name.size(); k++)
				cout << " ";*/
				del_one_object(all[kk].ID);
			}
		}//���н�ʬ�ƶ����
	}
}

//vector<Z_01> Z_01::all;
//vector<Z_02> Z_02::all;
//vector<Kunkun> Kunkun::all;






//���й������ʵ����
//Ordinary

//
////Z_01
//void Z_01::set_pos(const int &a, const int &b)
//{
//	row = a;
//	col = b;
//	x = 11 * (b - 1) + 1;
//	y = a * 5 + 2;
//}
//
//void Z_01::create(const int &a, const int &b)
//{
//	//���ӹ���
//	switch (what_tool)
//	{
//	case 0:
//	{
//		my_Tools = new Baseball;
//		my_Tools->set_pos(a, b);
//		my_Tools->set_cd(SP);
//		my_Tools->push();
//		break;
//	}
//	case 1:
//	{
//		my_Tools = new Baseball;
//		my_Tools->set_pos(a, b);
//		my_Tools->set_cd(SP);
//		my_Tools->push();
//		break;
//	}
//
//	default:
//	{
//
//		my_Tools = new Baseball;
//		my_Tools->set_pos(a, b);
//		my_Tools->set_cd(SP);
//		my_Tools->push();
//		break;
//	}
//	}
//
//	//���ɴ˽�ʬ
//	set_pos(a, b);
//	this->push();
//}
//
//void Z_01::print()
//{
//	for (size_t kk = 0; kk < this->get_num(); kk++)
//	{
//		all[kk].move();
//		all[kk].my_Tools->move();
//		all[kk].my_Tools->print();
//	}
//}
//
//void Z_01::move()
//{
//	for (size_t kk = 0; kk < this->get_num(); kk++)
//	{
//		all[kk].SP_begin++;
//		if (all[kk].col > 1)
//		{
//			if (all[kk].SP_begin == all[kk].SP)
//			{
//				//MoveTo(all[kk].x, all[kk].y);
//				//for (size_t k = 0; k < all[kk].name.size(); k++)
//				//cout << " ";
//				if (all[kk].x + all[kk].name.size() == 11 * (all[kk].col - 1))
//				{
//					MoveTo(all[kk].x + all[kk].name.size(), all[kk].y);
//					cout << get_back_ground();
//					all[kk].col--;
//				}
//				all[kk].x -= 1;
//				all[kk].SP_begin = 0;
//			}
//		}
//	}
//}
//
//
////Z_02
//void Z_02::set_pos(const int &a, const int &b)
//{
//	row = a;
//	col = b;
//	x = 11 * (b - 1) + 1;
//	y = a * 5 + 2;
//}
//
//void Z_02::create(const int &a, const int &b)
//{
//	//���ӹ���
//	switch (what_tool)
//	{
//	case 0:
//	{
//		my_Tools = new Pole_Vaulting;
//		my_Tools->set_pos(a, b);
//		my_Tools->set_cd(SP);
//		my_Tools->push();
//		break;
//	}
//	case 1:
//	{
//		my_Tools = new Chemist;
//		my_Tools->set_pos(a, b);
//		my_Tools->set_cd(SP);
//		my_Tools->push();
//		break;
//	}
//	
//
//	default:
//	{
//		my_Tools = new Pole_Vaulting;
//		my_Tools->set_pos(a, b);
//		my_Tools->set_cd(SP);
//		my_Tools->push();
//		break;
//	}
//	}
//
//	//���ɴ˽�ʬ
//	set_pos(a, b);
//	this->push();
//}
//
//void Z_02::print()
//{
//	for (size_t kk = 0; kk < this->get_num(); kk++)
//	{
//		all[kk].move();
//		all[kk].my_Tools->move();
//		all[kk].my_Tools->print();
//	}
//}
//
//void Z_02::move()
//{
//	for (size_t kk = 0; kk < this->get_num(); kk++)
//	{
//		all[kk].SP_begin++;
//		if (all[kk].col > 1)
//		{
//			if (all[kk].SP_begin == all[kk].SP)
//			{
//				//MoveTo(all[kk].x, all[kk].y);
//				//for (size_t k = 0; k < all[kk].name.size(); k++)
//				//cout << " ";
//				if (all[kk].x + all[kk].name.size() == 11 * (all[kk].col - 1))
//				{
//					MoveTo(all[kk].x + all[kk].name.size(), all[kk].y);
//					cout << get_back_ground();
//					all[kk].col--;
//				}
//				all[kk].x -= 1;
//				all[kk].SP_begin = 0;
//			}
//		}
//	}
//}
//
//
//
//
////Kunkun
//void Kunkun::set_pos(const int &a, const int &b)
//{
//	row = a;
//	col = b;
//	x = 11 * (b - 1) + 1;
//	y = a * 5 + 2;
//}
//
//void Kunkun::create(const int &a, const int &b)
//{
//	//���ӹ���
//	if (is_about_to_die == 1)
//	{
//		switch (what_tool)
//		{
//		case 0:
//		{
//			my_Tools = new Baseball;
//			my_Tools->set_pos(a, b);
//			my_Tools->set_cd(SP);
//			my_Tools->push();
//			break;
//		}
//		default:
//		{
//			my_Tools = new Baseball;
//			my_Tools->set_pos(a, b);
//			my_Tools->set_cd(SP);
//			my_Tools->push();
//			break;
//		}
//		}
//	}
//
//	//���ɴ˽�ʬ
//	set_pos(a, b);
//	this->push();
//}
//
//void Kunkun::print()
//{
//	for (size_t kk = 0; kk < this->get_num(); kk++)
//	{
//		all[kk].move();
//		all[kk].my_Tools->move();
//		all[kk].my_Tools->print();
//	}
//}
//
//void Kunkun::move()
//{
//	for (size_t kk = 0; kk < this->get_num(); kk++)
//	{
//		all[kk].SP_begin++;
//		if (all[kk].col > 1)
//		{
//			if (all[kk].SP_begin == all[kk].SP)
//			{
//				//MoveTo(all[kk].x, all[kk].y);
//				//for (size_t k = 0; k < all[kk].name.size(); k++)
//				//cout << " ";
//				if (all[kk].x + all[kk].name.size() == 11 * (all[kk].col - 1))
//				{
//					MoveTo(all[kk].x + all[kk].name.size(), all[kk].y);
//					cout << get_back_ground();
//					all[kk].col--;
//				}
//				all[kk].x -= 1;
//				all[kk].SP_begin = 0;
//			}
//		}
//	}
//}
