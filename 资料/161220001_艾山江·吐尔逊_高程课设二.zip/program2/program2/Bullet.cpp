#include "Bullet.h"
#include "UI.h"
#include"Lawn.h"
//��̬������ʼ����
vector<Org_pea> Org_pea::all;
int Org_pea::num = 0;



void Org_pea::print()
{
	int numm = all.size();
	vector<Org_pea>::iterator it;
	for (it = all.begin(); it != all.end(); it++)
	{
		MoveTo(it->pos[2], it->pos[3]);
		cout << it->shap;
	}
}

void Org_pea::move()
{
	Lawn L;
	for (size_t kk = 0; kk < this->get_num(); kk++)
	{
		int is_delete = 0;
		if (all[kk].pos[1] <= get_screen_data()[1])
		{
			for (size_t i = 0; i < L.get_num(); i++)
			{
				bool is_time_to_break = 0;
				//�ҵ����ӵ���ǰ��ƺ
				if (L.all[i].one_block[0] == all[kk].pos[0] && L.all[i].one_block[1] == all[kk].pos[1])
				{
					int meet_zombie = 0;
					is_time_to_break = 1;
					for (size_t j = 0; j < L.all[i].how_many_Z.size(); j++)
					{	
						//������ֽ�ʬ
						if (L.all[i].how_many_Z[j].type == 0)
						{
							if (L.all[i].how_many_Z[j].pos[0] == all[kk].pos[0] && L.all[i].how_many_Z[j].pos[2] == all[kk].pos[2])
							{
								meet_zombie = 1;
								L.all[i].plant_attack(1, all[kk].ID, all[kk].pos, all[kk].data);
								vector<int>jj = all[kk].pos;//����shi�ã���ͷɾ��
								string idd = all[kk].ID;
								int si = all.size();
								//�����ӵ�
								MoveTo(all[kk].pos[2], all[kk].pos[3]);
								for (size_t k = 0; k < all[kk].shap.size(); k++)
									cout << " ";
								//L.all[i].del_plant_attack(all[kk].ID);
								del_one_object(all[kk].ID);
								is_delete = 1;
								int sii = all.size();
								break;
							}							
						}
						else
						{
							//û������ʬ����������ʬ�ӵ�
						}
					}
					if (meet_zombie == 0)
					{
						all[kk].shoot_CD[2]++;
						if (all[kk].shoot_CD[2] == all[kk].shoot_CD[1])
						{
							MoveTo(all[kk].pos[2], all[kk].pos[3]);
							for (size_t k = 0; k < all[kk].shap.size(); k++)
								cout << " ";
							if (all[kk].pos[2]+all[kk].shap.size() == create_pos(all[kk].pos[0], all[kk].pos[1]+1)[2]-1)
							{
								all[kk].pos[1]++;
							}
							if (all[kk].pos[2] == create_pos(all[kk].pos[0], all[kk].pos[1])[2])
							{
								MoveTo(all[kk].pos[2]-1, all[kk].pos[3]);
								cout << get_back_ground();								
							}
							all[kk].pos[2] += 1;
							all[kk].shoot_CD[2] = 0;
						}
					}
				}
				if (is_time_to_break == 1)
					break;
			}//���в�ƺ
		}
		else
		{
			del_one_object(all[kk].ID);
		}
		if (is_delete == 1)
			break;
	}//�����ӵ�
}

//vector<Snow_pea> Snow_pea::all;
//vector<Melon> Melon::all;

//���й������ʵ����



//��ǰ��Move������̭��

//void Org_pea::move()
//{
//	Lawn L;
//	for (size_t kk = 0; kk < this->get_num(); kk++)
//	{
//		if (all[kk].pos[1] < 11)
//		{
//			for (size_t i = 0; i < L.get_num(); i++)
//			{
//				//�ҵ����ӵ�ǰһ����ƺ
//				if (L.all[i].pos[0] == all[kk].pos[0] && L.all[i].pos[1] == all[kk].pos[1] + 1)
//				{
//					for (size_t j = 0; j < L.all[i].what_Z_AT.size(); j++)
//					{
//						//������ֽ�ʬ
//						if (L.all[i].what_Z_AT[j] == 1)
//						{
//							L.all[i].what_P_AT.push_back(1);
//							L.all[i].how_much_P_AT.push_back(all[kk].data[4]);
//							all[kk].del_one_object(kk);
//						}
//						else
//						{
//							all[kk].shoot_CD[2]++;
//							if (all[kk].shoot_CD[2] == all[kk].shoot_CD[1])
//							{
//								MoveTo(all[kk].pos[2], all[kk].pos[3]);
//								for (size_t k = 0; k < all[kk].shap.size(); k++)
//									cout << " ";
//								if (all[kk].pos[2] - all[kk].shap.size() == 11 * (all[kk].pos[1]))
//								{
//									MoveTo(all[kk].pos[2] - all[kk].shap.size(), all[kk].pos[3]);
//									cout << get_back_ground();
//									all[kk].pos[1]++;
//								}
//								all[kk].pos[2] += 1;
//								all[kk].shoot_CD[2] = 0;
//							}
//						}
//					}//���н�ʬ
//				}
//			}//���в�ƺ
//		}
//		else
//		{
//			del_one_object(kk);
//		}
//	}//�����ӵ�
//}








