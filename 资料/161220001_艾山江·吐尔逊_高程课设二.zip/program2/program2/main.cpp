
#include "Control.h"
#define  R 50
#define  z_l 3
//void old();



int main()
{
	/*while (1)
	{
		int a = _getch();
		cout << a << "   ";
		int b = _getch();

		cout<<b << endl;
	}
	*/

	//��ʼ����Ļ����ƺ��
	set_screen();
	//������Ϸ
	play();


	return 0;
}

//
//void old()
//{
//	string bullit = " > ";
//	int count = 0;
//	vector<int> location;
//	int m_l = 3;
//	int what_bullit = 0;
//	for (int i = 4, j = 0, k = R, m = 0; j < 10;)
//	{
//		MoveTo(0, j);
//		cout << "doudou";
//		if (count > 0)
//		{
//			for (int c2 = 0; c2 < count; c2++)
//			{
//				MoveTo(location[c2] + 1, j);
//				cout << bullit;
//				location[c2] += 1;
//			}
//		}
//		MoveTo(k, j);
//		cout << " ��ʬ ";
//		MoveTo(0, j + 1);
//		cout << "--------------------------------------------------------------";
//		i++;
//		k--;
//		if (i % 5 == 0)
//		{
//			MoveTo(5, j);
//			cout << bullit;
//			count++;
//			location.push_back(5);
//		}
//		if (count > 0)
//		{
//			if (location[what_bullit] == k - 2 || location[what_bullit] == k - 2 || location[what_bullit] == k - 2 || location[what_bullit] == k || location[what_bullit] == k - 1 || location[what_bullit] == k - 3 || location[what_bullit] == k - 4)
//			{
//				m_l--;
//				what_bullit++;
//			}
//		}
//		if (m_l < 0)
//		{
//			MoveTo(k + 1, j);
//			cout << "��ʬ";
//			j += 2;
//			i = 4;
//			k = R;
//			count = 0;
//			location.clear();
//			what_bullit = 0;
//			m_l = 3;
//		}
//		Sleep(300);
//	}
//}