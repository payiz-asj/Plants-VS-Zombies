#pragma once 
#ifndef  ASJ_PLANT
#define  ASJ_PLANT

#include <Windows.h>
#include <string>
#include <tchar.h>
#include <time.h>
#include<vector>
#include <iostream>
#include <conio.h>
#include <sstream>
#include "Bullet.h"
#include "Lawn.h"
#include "UI.h"
using namespace std;



class Plants
{
public:
	Plants(){}
	virtual ~Plants(){}
	//�޸�
	virtual void set_bullet_type(const int &i) = 0;
	virtual void set_pos(const vector<int> & where) = 0;
	//virtual void set_solo_cd(const vector<int> & a) = 0;
	virtual void set_data(const vector<double> &a) = 0;
	virtual void create(const vector<int> & where) = 0;
	virtual void del_one_object(const size_t &i) = 0;
	//virtual void push() = 0;
	virtual void Cannot_attack() = 0;
	//��ȡ
	virtual int get_bullet_type() = 0;
	virtual Bullet* get_bullets() = 0;
	virtual vector<int> get_pos() = 0;
	virtual vector<double> get_data() = 0;
	//virtual size_t get_num() = 0;
	//virtual Plants *get_one_object(const size_t &i) = 0;
	virtual string get_ID() = 0;
	
	//����
	virtual void print() = 0;
	virtual void attack() = 0;
	virtual void solo() = 0;
	virtual void defance() = 0;
	virtual void move() = 0;

protected:
	string name;
	string ID;
	double  price;
	vector<int> pos;    //0 row    1  col   2  x   3  y 
	vector<double>data;	//0 MAX_XL  1  MAX_AT   2  MAX_DF  3 XL   4 AT  5  DF
	vector<int>solo_CD;	// 0  solo_CD   1  solo_CD_begin
	vector<int>shoot_CD;  //0   shoot_CD   1  shoot_CD_begin
	bool    is_alive;
	bool    is_can_attack;
	bool    is_can_solo;	
	bool    is_can_move;
	
};



class Peas :public Plants
{
	//vector<Peas> all;
	static int num;
	Bullet *my_Bullets;
	int    what_bullet;
public:
	Peas(){
		name   = "�㶹";
		ID     = "";
		price  = 100;
		data = { 100, 100, 0, 100, 100, 0 };
		solo_CD = { 0, 0 };
		shoot_CD = { 0, 0 };
		is_alive = 1;
		is_can_attack=0;
		is_can_solo = 0;
		is_can_move = 0;
		what_bullet = 0;
		my_Bullets = new Org_pea;
		num++;
	}
	~Peas(){ 
		/*delete my_Bullets;
		my_Bullets = NULL;*/
	}
	void set_bullet_type(const int &i)
	{
		what_bullet = i;
	}
	void set_pos(const vector<int> & where)
	{
		pos = where;
	}
	void set_shoot_cd(const vector<int> & a)
	{
		shoot_CD = a;
	}
	void set_data(const vector<double> &a)
	{
		data = a;
	}
	void create(const vector<int> & where);
	void del_one_object(const size_t &i)
	{
		size_t k = 0;
		/*vector<Peas>::iterator it;
		for (it = all.begin(); it != all.end(); it++, k++)
		{
			if (k == i)
			{
				it = all.erase(it);
				break;
			}
		}*/
	}
	/*void push()
	{
	all.push_back(*this);
	}*/
	void Cannot_attack()
	{
		is_can_attack = 0;
	}
	//��ȡ����
	int get_bullet_type()
	{
		return what_bullet;
	}
	Bullet *get_bullets()
	{
		return my_Bullets;
	}
	vector<int> get_pos()
	{
		return pos;
	}
	vector<double>get_data()
	{
		return data;
	}
	//size_t get_num()
	//{
	//	/*return all.size();*/
	//}
	//Plants *get_one_object(const size_t &i)
	//{
	//	/*return &all[i];*/
	//}
	string get_ID()
	{
		return ID;
	}

	//����
	void print();
	void attack();
	void shoot();
	void solo()
	{

	}
	void defance();

	void move();

	
};

//
//
////���̹���
//class p_02 :public Plants
//{
//	static vector<p_02> all;
//	Bullet *my_Bullets;
//	int what_bullet;
//public:
//	p_02()
//	{
//		name = "�ѹ�";
//		type = "����ֲ��";
//		price = 100;
//		MAX_XL = 100;
//		XL = 100;
//		AT = 200;
//		CD = 20;
//		CD_begin = 0;
//		is_alive = 1;
//		shine = 0;
//		CD_begin = 0;
//		what_bullet = 0;
//		my_Bullets = NULL;
//	
//	}
//	void select_tool(int i);
//	void set_cd(int mcd);
//	vector<int> set_pos(const vector<int> & where)
//	{
//		row = where[0];
//		col = where[1];
//		x = where[2];
//		y = where[3];
//	}
//	vector<int> get_pos()
//	{
//		vector<int> r;
//		r.push_back(row);
//		r.push_back(col);
//		r.push_back(x);
//		r.push_back(y);
//		return r;
//	}
//	void create(const int &a, const int &b);
//
//	void print();
//	void move()
//	{
//		//��ʱ������ֲ���ƶ�
//	}
//	void attak()
//	{
//		shoot();
//	}
//	double get_AT()
//	{
//		return AT;
//	}
//	void shoot()
//	{
//		CD_begin++;
//		if (CD_begin == CD)
//		{
//			//��������
//			
//			shine = 1;
//			CD_begin = 0;
//		}
//	}
//	void push()
//	{
//		all.push_back(*this);
//	}
//	size_t get_num()
//	{
//		return all.size();
//	}
//	Plants* get_one_object(size_t i)
//	{
//		return &all[i];
//	}
//	void del_one_object(size_t i)
//	{
//		size_t k = 0;
//		vector<p_02>::iterator it;
//		for (it = all.begin(); it != all.end(); it++, k++)
//		{
//			if (k == i)
//			{
//				it = all.erase(it);
//			}
//		}
//	}
//	int get_row()
//	{
//		return row;
//	}
//	int get_col()
//	{
//		return col;
//	}
//	string get_type()
//	{
//		return type;
//	}
//	Bullet* get_bullet()
//	{
//		return my_Bullets;
//	}
//	int get_bullet_type()
//	{
//		return what_bullet;
//	}
//};
//
////Ч����
//class  Sunflower:public Plants
//{
//	static vector<Sunflower> all;
//	int what_bullet;
//	Bullet * my_Bullets;
//public:
//	Sunflower()
//	{
//		name = "���տ�";
//		type = "������";
//		price = 100;
//		MAX_XL = 100;
//		XL = 100;
//		AT = 0;
//		CD = 40;
//		CD_begin = 0;
//		is_alive = 1;
//		what_bullet = 0;
//		my_Bullets = NULL;
//	}
//	void select_tool(int i)
//	{
//		what_bullet = i;
//	}
//	vector<int> set_pos(const vector<int> & where)
//	{
//		row = where[0];
//		col = where[1];
//		x = where[2];
//		y = where[3];
//	}
//	vector<int> get_pos()
//	{
//		vector<int> r;
//		r.push_back(row);
//		r.push_back(col);
//		r.push_back(x);
//		r.push_back(y);
//		return r;
//	}
//	void create(const int &a, const int &b)
//	{
//		set_pos(a, b);
//		this->push();
//	}
//	void print()
//	{
//		create_sun();
//		for (size_t i = 0; i < this->get_num(); i++)
//		{
//			MoveTo(all[i].x, all[i].y);
//			cout << all[i].name;
//		}
//	}
//	void create_sun()
//	{
//		//��������
//	}
//	void move()
//	{
//		//��ʱ������ֲ���ƶ�
//	}
//	void push()
//	{
//		all.push_back(*this);
//	}
//	size_t get_num()
//	{
//		return all.size();
//	}
//	void attak()
//	{
//
//	}
//	double get_AT()
//	{
//		return AT;
//	}
//	void set_cd(int mcd)
//	{
//		CD = mcd;
//	}
//	Plants* get_one_object(size_t i)
//	{
//		return &all[i];
//	}
//	void del_one_object(size_t i)
//	{
//		size_t k = 0;
//		vector<Sunflower>::iterator it;
//		for (it = all.begin(); it != all.end(); it++, k++)
//		{
//			if (k == i)
//			{
//				it = all.erase(it);
//			}
//		}
//	}
//	string get_type()
//	{
//		return type;
//	}
//	Bullet* get_bullet()
//	{
//		return my_Bullets;
//	}
//	int get_bullet_type()
//	{
//		return what_bullet;
//	}
//};
//








#endif 





