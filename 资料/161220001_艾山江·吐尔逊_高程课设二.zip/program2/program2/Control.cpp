#include "Control.h"
#include "UI.h"
#include"Lawn.h"
#include<ctime>
//���������
int Random(const int &a, const int &b)
{
	int r = rand() % (b - a + 1) + a;
	return r;
}

int game_speed = 30;
int max_row = get_chicun()[0];
int max_col = get_chicun()[1];
int current_row = 1;
int current_col = 1;

vector<Plants *> all_plants;
vector<Zombies *> all_Zombies;

void put_little_zombie()
{
	srand((int)time(0));  // �����������  ��0����NULLҲ��
	int Zom_type=Random(1, 1);
	switch (Zom_type)
	{
	case 1:
	{
		all_Zombies[0] = new Ordinary;
		int Zom_tool = Random(1, 1);
		all_Zombies[0]->set_tool_type(Zom_tool);
		break;
	}
	//case 2:
	//{
	//	z1 = new Z_01;
	//	//int Zom_tool = Random(0, 4);
	//	z1->select_tool(1);
	//	break;
	//}
	//case 3:
	//{
	//	z1 = new Z_02;
	//	//int Zom_tool = Random(0, 4);
	//	z1->select_tool(1);
	//	break;
	//}
	default:
	{
		all_Zombies[0] = new Ordinary;
		int Zom_tool = Random(1, 1);
		all_Zombies[0]->set_tool_type(Zom_tool);
		break;
	}
	}
	vector<int> w;
	w = create_pos(Random(1, max_row), Random(max_col + 2, max_col + 2));
	all_Zombies[0]->create(w);
	
}

int get_order()
{
	int r = 0;
	vector<int> jianpanma1 = { 87, 119, 83, 115 , 65 , 97, 68, 100 ,112,80,32 ,61,45};
	vector<int> zhiling    = { 2 ,  2 , 3 ,  3 ,  4 ,  4 , 5 , 5   , 6 ,6 , 7 ,19,20};
	vector<int> jianpanma2 = { 72, 80, 75, 77,83, 13, 27, 73 , 81,134,133,68,67,66,65 };
	vector<int> zhiling2   = { 2 , 3 , 4 , 5 , 8, 9 , 10, 11 , 12 ,13,14 ,15,16,17,18};
	int key1 = _getch();
	for (size_t i = 0; i < jianpanma1.size(); i++)
	{
		if (jianpanma1[i] == key1)
		{
			r = zhiling[i];
		}
	}
	if (key1==0||key1==224)
	{
		int key2 = _getch();
		for (size_t i = 0; i < jianpanma2.size(); i++)
		{
			if (jianpanma2[i] == key2)
			{
				r = zhiling2[i];
			}
		}
	}
	return r;
}

//��������
int manipulate_order()
{
	int what=get_order();
	int status = 0;
	switch (what)
	{
	case 0:
	{

		break;
	}
	case 1:
	{

		break;
	}
	case 2:
	{

		break;
	}
	case 3:
	{

		break;
	}
	case 4:
	{

		break;
	}
	case 5:
	{

		break;
	}
	case 6:
	{
		//��Ϸ��ͣ
		while (1)
		{
			if (get_order() == 6)
				break;
		}
		break;
	}
	case 7:
	{

		break;
	}
	case 8:
	{

		break;
	}
	case 9:
	{

		break;
	}
	case 10:
	{

		break;
	}
	case 11:
	{

		break;
	}
	case 12:
	{

		break;
	}
	case 13:
	{

		break;
	}
	case 14:
	{

		break;
	}
	case 15:
	{

		break;
	}
	case 16:
	{

		break;
	}
	case 17:
	{

		break;
	}
	case 18:
	{

		break;
	}
	case 19:
	{
		//��Ϸ����
		if (game_speed > 7)
			game_speed -= 5;
		break;
	}
	case 20:
	{
		//��Ϸ����
		if (game_speed < 50)
			game_speed += 5;
		break;
	}
	default:
		break;
	}
	return status;
}

void play()
{
	Lawn L;
	L.init_lawn();
	Plants *p1 = new Peas;
	vector<int>where;
	p1->set_bullet_type(0);
	where = create_pos(1, 1);
	p1->create(where);

	Plants *p2 = new Peas;
	p2->set_bullet_type(0);
	where = create_pos(2, 1);
	p2->create(where);
	Plants *p3 = new Peas;
	p3->set_bullet_type(0);
	where = create_pos(3, 1);
	p3->create(where);


	all_plants.push_back(p1);
	all_plants.push_back(p2);
	all_plants.push_back(p3);
	

	int Zom_CD = 100;
	int Zom_count = 0;
	Zombies *z1=new Ordinary;
	all_Zombies.push_back(z1);
	put_little_zombie();
	while (1)
	{
		//����
		if (_kbhit())
		{
			manipulate_order();
		}
		//���������ʬ
		if (Zom_count == Zom_CD)
		{
			put_little_zombie();
			Zom_count = 0;
		}
		Zom_count++;

		//------���--------

		//1��ֲ���ʬ
		for (size_t i = 0; i < all_plants.size(); i++)
			all_plants[i]->attack();
		for (size_t i = 0; i < all_Zombies.size(); i++)
			all_Zombies[i]->defance();

		//2����ʬ�ػ�
		for (size_t i = 0; i < all_Zombies.size(); i++)
			all_Zombies[i]->attack();
		//for (size_t i = 0; i < all_plants.size(); i++)
		//	all_plants[i]->defance();

		//3�������ƶ�
		for (size_t i = 0; i < all_plants.size(); i++)
			all_plants[i]->move();
		for (size_t i = 0; i < all_Zombies.size(); i++)
			all_Zombies[i]->move();


		//��Ⱦ����ӡ
		for (size_t i = 0; i < all_plants.size(); i++)
			all_plants[i]->print();
		for (size_t i = 0; i < all_Zombies.size(); i++)
			all_Zombies[i]->print();

		//��Ϸ�ٶ�����
		Sleep(game_speed);	
	}




	cout << "��ӭ�´�������" << endl;

}
