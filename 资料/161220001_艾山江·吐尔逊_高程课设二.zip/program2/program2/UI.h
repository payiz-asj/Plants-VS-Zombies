#pragma once 
#ifndef  ASJ_UI
#define  ASJ_UI

#include <Windows.h>
#include <string>
#include <tchar.h>
#include <time.h>
#include<vector>
#include <iostream>
#include <conio.h>
using namespace std;

wchar_t string2wchar(const string& s);
void modeset(int w, int h);
void set_screen();
void MoveTo(int x, int y);
void select_back_ground();
void init_screen(char wall, int row, int col, int weight, int hight);

vector<int> get_screen_data();
vector<int> create_pos(const int &a, const int &b);
char get_back_ground();
int * get_chicun();



#endif 