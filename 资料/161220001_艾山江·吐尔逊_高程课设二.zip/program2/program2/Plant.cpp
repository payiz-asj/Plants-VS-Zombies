#include "Plant.h"
#include "UI.h"
#include"Lawn.h"

//��̬������ʼ����
//vector<Peas> Peas::all;
//vector<p_02> p_02::all;
//vector<Sunflower> Sunflower::all;
int Peas::num = 0;





//���й������ʵ����
//Զ��



void Peas::create(const vector<int> & where)
{
	vector<int> w;
	w = create_pos(where[0], where[1] + 1);
	switch (what_bullet)
	{
	case 0:
	{
		my_Bullets = new Org_pea;
		//my_Bullets->create(w);
		break;
	}
	/*case 1:
	{
	my_Bullets = new Snow_pea;
	my_Bullets->create(w);
	break;
	}
	case 2:
	{
	my_Bullets = new Melon;
	my_Bullets->create(w);
	break;
	}*/
	default:
	{
		my_Bullets = new Org_pea;
		//my_Bullets->create(w);
		break;
	}
	}
	this->set_pos(where);
	this->shoot_CD[0] = my_Bullets->get_cd()[0];
	this->name = my_Bullets->get_name() + name;
	stringstream Oss;
	Oss << num;
	this->ID = this->name + Oss.str();
	//this->push();
}

void Peas::print()
{
	/*	int num = this->get_num();
		for (size_t kk = 0; kk < this->get_num(); kk++)
		{
		if (all[kk].is_alive == 1)
		{
		MoveTo(all[kk].pos[2], all[kk].pos[3]);
		cout << all[kk].name;
		}
		else
		{
		this->del_one_object(kk);
		}
		all[kk].my_Bullets->print();
		}*/
	MoveTo(pos[2], pos[3]);
	cout << name;
	my_Bullets->print();
}

void Peas::attack()
{
	//Lawn L;
	//for (size_t kk = 0; kk < this->get_num(); kk++)
	//{
	//	all[kk].is_can_attack = 0;
	//	if (L.get_num() > 0)
	//	{
	//		for (size_t i = 0; i < L.get_num(); i++)
	//		{
	//			//�鿴����һ�����޽�ʬ
	//			if (L.all[i].pos[0] == all[kk].pos[0])
	//			{
	//				if (L.all[i].what_Z_AT.size()>0)
	//				{
	//					all[kk].is_can_attack = 1;
	//				}
	//			}
	//		}
	//	}
	//	else
	//	{
	//		all[kk].is_can_attack = 0;
	//	}
	//	//�ж�solo����
	//	if (all[kk].is_can_attack == 0)
	//	{
	//		all[kk].shoot();
	//	}
	//}	

	Lawn L;
	is_can_attack = 0;
	vector <int>howmany;
	for (size_t i = 0; i < L.get_num(); i++)
	{
		//�鿴����һ�����޽�ʬ
		if (L.all[i].one_block[0] == pos[0])
		{
			
			if (L.all[i].how_many_Z.size()>0)
			{
				for (size_t j = 0; j < L.all[i].how_many_Z.size(); j++)
				{
					if (L.all[i].how_many_Z[j].type == 0)
						is_can_attack = 1;
				}
				howmany.push_back(L.all[i].how_many_Z.size());
			}			
		}
	}
	if (is_can_attack == 1)
	{
		shoot();
	}
}

void Peas::shoot()
{
	/*for (size_t kk = 0; kk < this->get_num(); kk++)
	{
	all[kk].shoot_CD[1]++;
	int ddd = all[kk].shoot_CD[1];
	int fff = all[kk].shoot_CD[0];
	if (all[kk].shoot_CD[1] == all[kk].shoot_CD[0])
	{
	vector<int> w;
	w = create_pos(all[kk].pos[0], all[kk].pos[1] + 1);
	all[kk].my_Bullets->create(w);
	all[kk].shoot_CD[0] = my_Bullets->get_cd()[0];
	all[kk].shoot_CD[1] = 0;
	}
	}*/

	shoot_CD[1]++;
	int ddd = shoot_CD[1];
	int fff = shoot_CD[0];
	if (shoot_CD[1] == shoot_CD[0])
	{
		vector<int> w;
		w = create_pos(pos[0], pos[1] + 1);
		my_Bullets->create(w,this->ID);
		shoot_CD[0] = my_Bullets->get_cd()[0];
		shoot_CD[1] = 0;
	}
}

void Peas::defance()
{
	//Lawn L;
	//for (size_t kk = 0; kk < this->get_num(); kk++)
	//{
	//	for (size_t i = 0; i < L.get_num(); i++)
	//	{
	//		//�ҵ���ֲ�����ڲ�ƺ
	//		if (L.all[i].pos[0] == all[kk].pos[0] && L.all[i].pos[1] == all[kk].pos[1])
	//		{
	//			for (size_t j = 0; j < L.all[i].what_Z_AT.size(); j++)
	//			{
	//				//0  ҧ    1   �ӵ�
	//				if (L.all[i].what_P_AT[j] == 0 || L.all[i].what_P_AT[j] == 1)
	//				{
	//					if (all[kk].data[5] > L.all[i].how_much_Z_AT[j])
	//					{
	//						all[kk].data[5] -= L.all[i].how_much_Z_AT[j];
	//					}
	//					else
	//					{
	//						all[kk].data[5] = 0;
	//						all[kk].data[3] -= L.all[i].how_much_Z_AT[j] - all[kk].data[5];
	//					}
	//					//ɾ�����˺�
	//					L.all[i].del_one_zombie(j);

	//				}
	//				else
	//				{
	//					if (all[kk].data[5] > L.all[i].how_much_Z_AT[j])
	//					{
	//						all[kk].data[5] -= L.all[i].how_much_Z_AT[j];
	//					}
	//					else
	//					{
	//						all[kk].data[5] = 0;
	//						all[kk].data[3] -= L.all[i].how_much_Z_AT[j] - all[kk].data[5];
	//					}
	//					//ɾ�����˺�
	//					L.all[i].del_one_zombie(j);
	//				}
	//				if (all[kk].data[3] < 0)
	//					all[kk].is_alive = 0;
	//			}//�ò�ƺ�����˺��������
	//		}
	//	}
	//}

}

void Peas::move()
{
	//for (size_t kk = 0; kk < this->get_num(); kk++)
	//{
	//	if (all[kk].is_can_move != 0)
	//	{
	//		//һ���ֲ�ﶼ�����Լ��˶�
	//	}
	//	all[kk].my_Bullets->move();
	//}
	my_Bullets->move();
}
