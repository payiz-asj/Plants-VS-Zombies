#pragma once 
#ifndef  ASJ_BULLET
#define  ASJ_BULLET

#include <Windows.h>
#include <string>
#include <tchar.h>
#include <time.h>
#include<vector>
#include <iostream>
#include <conio.h>
#include <sstream>
using namespace std;


class Bullet
{
public:
	Bullet(){}
	virtual ~Bullet(){}
	//�޸�
	virtual void set_pos(const vector<int> & where) = 0;
	virtual void set_shoot_cd(const vector<int> & a) = 0;
	virtual void set_data(const vector<double> &a) = 0;
	virtual void create(const vector<int> & where, const string &s) = 0;
	//virtual void del_one_object(const size_t &i) = 0;
	virtual void del_one_object(const string &id) = 0;
	
	//��ȡ
	virtual vector<int> get_pos() = 0;
	virtual vector<double> get_data() = 0;
	virtual vector<int> get_cd() = 0;
	virtual size_t get_num() = 0;
	virtual Bullet *get_one_object(const size_t &i) = 0;
	virtual string get_ID() = 0;
	virtual string get_name() = 0;

	//����
	virtual void print() = 0;
	virtual void move() = 0;
protected:
	string	name;
	string  shap;
	string	ID;
	double  price;
	vector<int> pos;    //0 row    1  col   2  x   3  y 
	vector<double>data;	//0 MAX_XL  1  MAX_AT   2  MAX_DF  3 XL   4 AT  5  DF
	vector<int>shoot_CD;	// 0  shoot_CD  ����Ƶ��  1  SP  �ƶ��ٶ�   2  SP_begin

	virtual void push() = 0;


};

//Org_pea
class Org_pea :public Bullet
{
	static vector<Org_pea> all;
	static int num;
public:
	Org_pea()
	{
		name = "��ͨ";
		shap = "O";
		price = 100;
		data = { 100, 100, 0, 100, 100, 0 };
		shoot_CD = { 30,10, 0 };
		num++;

	}
	~Org_pea(){}
	void set_pos(const vector<int> & where)
	{
		pos = where;
	}
	void set_shoot_cd(const vector<int> & a)
	{
		shoot_CD = a;
	}
	void set_data(const vector<double> &a)
	{
		data = a;
	}
	void create(const vector<int> & where,const string &s )
	{
		this->set_pos(where);
		stringstream Oss;
		Oss << num;
		this->ID = s + Oss.str();
		this->push();
	}
	//void del_one_object(const size_t &i)
	//{
	//	size_t k = 0;
	//	vector<Org_pea>::iterator it;
	//	for (it = all.begin(); it != all.end(); it++, k++)
	//	{
	//		if (k == i)
	//		{
	//			it = all.erase(it);
	//			break;
	//		}
	//	}
	//}
	void del_one_object(const string &id)
	{
		vector<Org_pea>::iterator it;
		for (it = all.begin(); it != all.end(); it++)
		{
			if (it->ID == id)
			{
				it = all.erase(it);
				break;
			}
		}
	}
	void push()
	{
		all.push_back(*this);
	}
	//��ȡ����

	vector<int> get_pos()
	{
		return pos;
	}
	vector<double>get_data()
	{
		return data;
	}
	vector<int> get_cd()
	{
		return shoot_CD;
	}
	size_t get_num()
	{
		return all.size();
	}
	Bullet *get_one_object(const size_t &i)
	{
		return &all[i];
	}
	string get_ID()
	{
		return ID;
	}
	string get_name()
	{
		return name;
	}
	//����
	void print();
	void move();
	
};
//
////Snow_pea
//class Snow_pea :public Bullet
//{
//	static vector<Snow_pea> all;
//public:
//	Snow_pea()
//	{
//		name = "ѩ���㶹";
//		shap = "*";
//		price = 100;
//		data = { 100, 100, 0, 100, 100, 0 };
//		shoot_CD = { 4, 10, 0 };
//
//
//	}
//	~Snow_pea(){}
//	void set_pos(const vector<int> & where)
//	{
//		pos = where;
//	}
//	void set_shoot_cd(const vector<int> & a)
//	{
//		shoot_CD = a;
//	}
//	void set_data(const vector<double> &a)
//	{
//		data = a;
//	}
//	void create(const vector<int> & where)
//	{
//		this->set_pos(where);
//		this->push();
//	}
//	void del_one_object(const size_t &i)
//	{
//		size_t k = 0;
//		vector<Snow_pea>::iterator it;
//		for (it = all.begin(); it != all.end(); it++, k++)
//		{
//			if (k == i)
//			{
//				it = all.erase(it);
//				break;
//			}
//		}
//	}
//	void push()
//	{
//		all.push_back(*this);
//	}
//	//��ȡ����
//
//	vector<int> get_pos()
//	{
//		return pos;
//	}
//	vector<double>get_data()
//	{
//		return data;
//	}
//	vector<int> get_cd()
//	{
//		return shoot_CD;
//	}
//	size_t get_num()
//	{
//		return all.size();
//	}
//	Bullet *get_one_object(const size_t &i)
//	{
//		return &all[i];
//	}
//	string get_ID()
//	{
//		return ID;
//	}
//
//	//����
//	void print()
//	{
//		vector<Snow_pea>::iterator it;
//		for (it = all.begin(); it != all.end(); it++)
//		{
//			MoveTo(pos[2], pos[3]);
//			cout << it->shap;
//		}
//	}
//	void move()
//	{
//		for (size_t kk = 0; kk < this->get_num(); kk++)
//		{
//			shoot_CD[2]++;
//			if (pos[1] < 11)
//			{
//				if (shoot_CD[2] == shoot_CD[1])
//				{
//					MoveTo(pos[2], pos[3]);
//					for (size_t k = 0; k < all[kk].shap.size(); k++)
//						cout << " ";
//					if (pos[2] - all[kk].shap.size() == 11 * (pos[3]))
//					{
//						MoveTo(pos[2] - all[kk].shap.size(), pos[3]);
//						cout << get_back_ground();
//						pos[3]++;
//					}
//					pos[2] += 1;
//					shoot_CD[2] = 0;
//				}
//			}
//		}
//	}
//
//};
//
////Melon
//class Melon :public Bullet
//{
//	static vector<Melon> all;
//public:
//	Melon()
//	{
//		name = "����";
//		shap = "M";
//		price = 100;
//		data = { 100, 100, 0, 100, 100, 0 };
//		shoot_CD = { 4, 10, 0 };
//
//
//	}
//	~Melon(){}
//	void set_pos(const vector<int> & where)
//	{
//		pos = where;
//	}
//	void set_shoot_cd(const vector<int> & a)
//	{
//		shoot_CD = a;
//	}
//	void set_data(const vector<double> &a)
//	{
//		data = a;
//	}
//	vector<int> get_cd()
//	{
//		return shoot_CD;
//	}
//	void create(const vector<int> & where)
//	{
//		this->set_pos(where);
//		this->push();
//	}
//	void del_one_object(const size_t &i)
//	{
//		size_t k = 0;
//		vector<Melon>::iterator it;
//		for (it = all.begin(); it != all.end(); it++, k++)
//		{
//			if (k == i)
//			{
//				it = all.erase(it);
//				break;
//			}
//		}
//	}
//	void push()
//	{
//		all.push_back(*this);
//	}
//	//��ȡ����
//
//	vector<int> get_pos()
//	{
//		return pos;
//	}
//	vector<double>get_data()
//	{
//		return data;
//	}
//	size_t get_num()
//	{
//		return all.size();
//	}
//	Bullet *get_one_object(const size_t &i)
//	{
//		return &all[i];
//	}
//	string get_ID()
//	{
//		return ID;
//	}
//
//	//����
//	void print()
//	{
//		vector<Melon>::iterator it;
//		for (it = all.begin(); it != all.end(); it++)
//		{
//			MoveTo(pos[2], pos[3]);
//			cout << it->shap;
//		}
//	}
//	void move()
//	{
//		for (size_t kk = 0; kk < this->get_num(); kk++)
//		{
//			shoot_CD[2]++;
//			if (pos[1] < 11)
//			{
//				if (shoot_CD[2] == shoot_CD[1])
//				{
//					MoveTo(pos[2], pos[3]);
//					for (size_t k = 0; k < all[kk].shap.size(); k++)
//						cout << " ";
//					if (pos[2] - all[kk].shap.size() == 11 * (pos[3]))
//					{
//						MoveTo(pos[2] - all[kk].shap.size(), pos[3]);
//						cout << get_back_ground();
//						pos[3]++;
//					}
//					pos[2] += 1;
//					shoot_CD[2] = 0;
//				}
//			}
//		}
//	}
//
//};
//






#endif 

