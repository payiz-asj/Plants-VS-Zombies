#include "UI.h"

char back_ground_style = '.';
int zhiliuqu = 5;//��ƺ�Ϸ�����������������ʾ�������
int all_row = 5;
int all_col = 10;
int one_weight = 10;
int one_hight = 4;



vector<int> get_screen_data()
{
	vector<int> p;
	p.push_back(all_row);
	p.push_back(all_col);
	p.push_back(one_weight);
	p.push_back(one_hight);
	return p;
}


vector<int> create_pos(const int &a, const int &b)
{
	vector<int> p;
	int xx, yy;
	p.push_back(a);
	p.push_back(b);
	xx = (one_weight+1 )* (b - 1) + 1;
	yy = (one_hight + 1)* (a - 1) + zhiliuqu + 1;
	p.push_back(xx);
	p.push_back(yy);
	return p;
}

char get_back_ground()
{
	return back_ground_style;
}
int * get_chicun()
{
	int a[4];
	a[0] = all_row;
	a[1] = all_col;
	a[2] = one_weight;
	a[3] = one_weight;
	int *pp = a;
	return pp;
}
wchar_t string2wchar(const string& s)
{
	int len;
	int slength = (int)s.length() + 1;
	len = MultiByteToWideChar(CP_ACP, 0, s.c_str(), slength, 0, 0);
	wchar_t* buf = new wchar_t[len];
	MultiByteToWideChar(CP_ACP, 0, s.c_str(), slength, buf, len);
	return *buf;
}

void set_screen()
{
	// ��ȡ��׼����豸���
	HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);
	// ��ȡ���ڻ�������Ϣ
	PCONSOLE_SCREEN_BUFFER_INFO bInfo = new CONSOLE_SCREEN_BUFFER_INFO;
	GetConsoleScreenBufferInfo(hOut, bInfo);
	
	// ���ô��ڱ���
	LPWSTR title = _T("ֲ���ս��ʬPAYIZ��");
	//GetConsoleTitle(title, 255); // ��ȡ���ڱ���
	SetConsoleTitle(title);    

	/*COORD size = { 150, 37};
	SetConsoleScreenBufferSize(hOut, size);
	SMALL_RECT rc = { 0, 0, 140, 32 };
	SetConsoleWindowInfo(hOut, 1, &rc);*/

	//HWND ho = GetConsoleWindow();
	//MoveWindow(ho, 0, 0, 1000, 600, 1);
	
	
	//system("mode con cols=100 lines=25");   //�ÿ���̨����ʵ��
	
	//COORD pos = { 0, 0 };
	//FillConsoleOutputCharacter(hOut, 'A', bInfo->dwSize.X * bInfo->dwSize.Y,pos, NULL);

	//��APIʵ��
	int cx = GetSystemMetrics(SM_CXSCREEN);            /* ��Ļ���� ���� */
	int cy = GetSystemMetrics(SM_CYSCREEN);            /* ��Ļ�߶� ���� */
	HWND hwnd = GetForegroundWindow();
	
	LONG l_WinStyle = GetWindowLong(hwnd, GWL_STYLE);   /* ��ȡ������Ϣ */
	/* ���ô�����Ϣ ��� ȡ�����������߿� */
	//SetWindowLong(hwnd, GWL_STYLE, (l_WinStyle | WS_POPUP | WS_MAXIMIZE) & ~WS_CAPTION & ~WS_THICKFRAME & ~WS_BORDER);
	SetWindowLong(hwnd, GWL_STYLE, (l_WinStyle | WS_MAXIMIZE)  & ~WS_THICKFRAME);
	
	COORD front_size;
	front_size.X = cx/8-1;
	front_size.Y = cy/18-3;
	SetConsoleScreenBufferSize(hOut, front_size);
	//SMALL_RECT rc = { 0, 0,front_size.X-1,front_size.Y-1 };
	//SetConsoleWindowInfo(hOut, 1, &rc);
	SetWindowPos(hwnd, HWND_TOP, 0, 0, cx,cy, 0);
	//_tsetlocale(LC_ALL, _T("chs"));
	system(" CHCP 936");
	system("cls");
	//CloseHandle(hOut); // �رձ�׼����豸���	

	//����ǽ��
	select_back_ground();
	init_screen(back_ground_style, all_row, all_col, one_weight, one_hight);
}

void MoveTo(int x, int y)
{
	HANDLE hStd = GetStdHandle(STD_OUTPUT_HANDLE);
	COORD crPlayer = { x, y };
	SetConsoleCursorPosition(hStd, crPlayer);
}


void select_back_ground()
{

	size_t flag = 0;
	int if_quit = 0;
	vector<char> p = { '.', ',', '-','x', '@', '#', 'c', 'v', '/', '\\', '5' };
	while (1)
	{
		MoveTo(40, 0);
		cout << "ǽ�����ã��밴 ���ϼ�(��s) �����¼�(��s)����ѡ�񣬰� Enter ����ȷ�� ";
		int key1 = _getch();
		if (key1 == 13)
		{
			init_screen(p[flag],all_row,all_col,one_weight,one_hight);
			break;
		}

		int key2 = _getch();

		//if (_kbhit())
		switch (key2)
		{
		case 13:
			init_screen(p[flag], all_row, all_col, one_weight, one_hight);
			if_quit = 1;
			break;
		case 72:
			if (flag > 0)
				flag--;
			else
				flag = p.size() - 1;
			init_screen(p[flag], all_row, all_col, one_weight, one_hight);
			break;
		case 80:
			if (flag < p.size() - 1)
				flag++;
			else
				flag = 0;
			init_screen(p[flag], all_row, all_col, one_weight, one_hight);
			break;
		default:
			if (key1 == 119)
			{
				if (flag > 0)
					flag--;
				else
					flag = p.size() - 1;
				init_screen(p[flag], all_row, all_col, one_weight, one_hight);
				break;
			}
			else if (key1 == 115)
			{
				if (flag < p.size() - 1)
					flag++;
				else
					flag = 0;
				init_screen(p[flag], all_row, all_col, one_weight, one_hight);
				break;
			}
			else
			{
				flag = 0;
				init_screen(p[flag], all_row, all_col, one_weight, one_hight);
				break;
			}
		}
		if (if_quit)
			break;
	}
	back_ground_style = p[flag];
	system("cls");
}

void init_screen(char wall,int row,int col,int weight,int hight)
{
	int count = 0;
	for (int j = zhiliuqu; j < (row*(hight+1)+1+zhiliuqu); j++)
	{
		if (count == row || j == row)
		{
			for (int i = 0; i <(col*(weight+1)+1); i++)
			{
				MoveTo(i, j);
				cout <<wall;
			}
			count = 0;
		}
		else
		{
			for (int i = 0; i < (col*(weight + 1) + 1); i +=(weight+1))
			{
				MoveTo(i, j);
				cout <<wall;
			}
		}
		count++;
	}
	
	//������ʬ������
	int how_far = 30;
	for (int i = (col*(weight + 1) + 1); i < (col*(weight + 1) + 1)+how_far; i++)
	{
		MoveTo(i, zhiliuqu);
		cout << "!";
		MoveTo(i, (row*(hight + 1) + 1 + zhiliuqu)-1);
		cout <<"!";
	}
	for (int j = zhiliuqu; j < (row*(hight + 1) + 1 + zhiliuqu); j++)
	{
		MoveTo((col*(weight + 1) + 1) + how_far, j);
		cout << "!";
	}




}